export { default } from "../Tetris";
