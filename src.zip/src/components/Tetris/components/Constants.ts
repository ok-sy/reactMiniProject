const TETROMINO_LIST = [
  [
    [1, 1, 0],
    [0, 1, 1],
    [0, 0, 0],
  ],
  // 다른 테트리스 조각들...
];

export default TETROMINO_LIST;
