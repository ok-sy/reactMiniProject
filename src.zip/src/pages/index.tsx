export { default } from "./MainPage";
