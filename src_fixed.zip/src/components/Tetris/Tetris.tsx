//component
import { Box } from "@mui/material";
import { useState } from "react";
import Display from "../Display";
import createStage from "../gameHelper";
import Stage from "./components/Stage";
import StartButton from "./components/StartButton";

//style
import { StyledTetris, StyledTetrisWrapper } from "./styles/StyledTetris";

//Custom Hooks
import usePlayer from '../Tetris/hooks/usePlayer';
import useStage from '../Tetris/hooks/useStage';

export default function Tetris() {
  const [dropTime, setDropTime] = useState<number | null>(null);
  const [gameOver, setGameOver] = useState(false);

  const { player, updatePlayerPos, resetPlayer } = usePlayer();
  const { stage, setStage } = useStage(player, resetPlayer);

  const startGame = () => {
    // Reset everything
    setStage(createStage() as any);
    resetPlayer();
    setGameOver(false);
    setDropTime(1000);
  };

  return (
    <Box sx={StyledTetrisWrapper}>
      <Box className="tetris" sx={StyledTetris}>
        <Stage stage={stage as any} />
        <aside>
          {gameOver ? (
            <Display gameOver={"true"} text={"Game Over"} />
          ) : (
            <div>
              <Display gameOver={""} text={"Score"} />
              <Display gameOver={""} text={"Rows"} />
              <Display gameOver={""} text={"Level"} />
            </div>
          )}
          <StartButton callBack={startGame} />
        </aside>
      </Box>
    </Box>
  );
}
