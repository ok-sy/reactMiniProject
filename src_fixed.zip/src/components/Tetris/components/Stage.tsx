import React from "react";
import Cell from "./Cell";
import { Box } from "@mui/material";
import { StyledStage } from "../styles/StyledStage";
import { TetrominoType } from "../../tetrominos";
import type { StageGrid } from "../hooks/useStage";

type StageProps = {
  stage: StageGrid;
};

export default function Stage({ stage }: StageProps) {
  return (
    <Box
      className="Stage"
      sx={StyledStage({ width: stage[0].length, height: stage.length })}
    >
      {stage.map((row, y) => (
        <Box
          key={y}
          className="row"
          sx={{ display: "grid", gridTemplateColumns: `repeat(${row.length}, 1fr)` }}
        >
          {row.map((cell, x) => (
            <Cell key={x} type={cell[0] as TetrominoType} />
          ))}
        </Box>
      ))}
    </Box>
  );
}
