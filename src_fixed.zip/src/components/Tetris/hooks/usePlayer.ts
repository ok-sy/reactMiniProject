import { useCallback, useState } from 'react'
import { randomTetromino } from '../../tetrominos'
import { STAGE_WIDTH } from '../../gameHelper'

type Player = {
  pos: { x: number; y: number };
  tetromino: (string | number)[][];
  collided: boolean;
};

export default function usePlayer() {
  const { shape } = randomTetromino();
  const [player, setPlayer] = useState<Player>({
    pos: { x: Math.floor(STAGE_WIDTH / 2) - 2, y: 0 },
    tetromino: shape,
    collided: false,
  });

  const updatePlayerPos = ({ x, y, collided }: { x: number; y: number; collided: boolean }) => {
    setPlayer(prev => ({
      ...prev,
      pos: { x: prev.pos.x + x, y: prev.pos.y + y },
      collided,
    }));
  };

  const resetPlayer = useCallback(() => {
    const { shape } = randomTetromino();
    setPlayer({
      pos: { x: Math.floor(STAGE_WIDTH / 2) - 2, y: 0 },
      tetromino: shape,
      collided: false,
    });
  }, []);

  return { player, setPlayer, updatePlayerPos, resetPlayer };
}
