import { SxProps } from "@mui/material";

type Props = {
  width: number;
  height: number;
};

export const StyledStage = ({ width, height }: Props): SxProps => ({
  display: "grid",
  gridTemplateRows: `repeat(${height}, 1fr)`,
  gridTemplateColumns: `repeat(${width}, 1fr)`,
  gap: "1px",
  width: "40%",
  maxWidth: "25vw",
  background: "#111",
});
